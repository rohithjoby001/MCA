package com.example.my_application;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    EditText num1,num2;
    TextView r;
    Button bt1,bt2,bt3,bt4;
    double a,b,c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1=(EditText) findViewById(R.id.first);
        num2=(EditText) findViewById(R.id.second);
        bt1=(Button) findViewById(R.id.buttonadd);
        bt2=(Button) findViewById(R.id.buttonsub);
        bt3=(Button) findViewById(R.id.buttonmul);
        bt4=(Button) findViewById(R.id.buttondiv);
        r=(TextView) findViewById(R.id.result);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Double.parseDouble(num1.getText().toString());
                b=Double.parseDouble(num2.getText().toString());
                c=a+b;
                r.setText(""+c);
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Double.parseDouble(num1.getText().toString());
                b=Double.parseDouble(num2.getText().toString());
                c=a-b;
                r.setText(""+c);
            }
        });
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Double.parseDouble(num1.getText().toString());
                b=Double.parseDouble(num2.getText().toString());
                c=a*b;
                r.setText(""+c);
            }
        });
        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Double.parseDouble(num1.getText().toString());
                b=Double.parseDouble(num2.getText().toString());
                c=a/b;
                r.setText(""+c);
            }
        });

    }
}