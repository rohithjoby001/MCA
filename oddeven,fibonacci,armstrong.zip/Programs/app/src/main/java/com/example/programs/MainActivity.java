package com.example.programs;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    EditText t1;
    Button E1,f1,a1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1=(EditText) findViewById(R.id.txtInp);
        E1=(Button)findViewById(R.id.oddEven);
        f1=(Button)findViewById(R.id.fibonacci);
        a1=(Button)findViewById(R.id.arm);
        E1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = t1.getText().toString();
                int Value=Integer.parseInt(a);
                if (Value % 2 == 0) {
                    Toast.makeText(MainActivity.this, Value+" is Even", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, Value +" is Odd", Toast.LENGTH_SHORT).show();
                }
            }
        });
        f1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int limit = Integer.parseInt(t1.getText().toString());
                int first = 0;
                int second = 1;
                StringBuilder sb = new StringBuilder();
                sb.append("Fibonacci series up to ").append(limit).append(": ");

                while (first <= limit) {
                    sb.append(first).append(" ");
                    int sum = first + second;
                    first = second;
                    second = sum;
                }

                Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int ognum,rem;
                int res=0;
                int num=Integer.parseInt(t1.getText().toString());
                ognum=num;
                while(ognum!=0){
                    rem = ognum%10;
                    res= res+(rem*rem*rem);
                    ognum=ognum/10;
                }
                if(res==num){
                    Toast.makeText(MainActivity.this, num+" is an Armstrong", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(MainActivity.this, num+" is Not an Armstrong", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
