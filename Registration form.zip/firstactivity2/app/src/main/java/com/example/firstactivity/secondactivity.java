package com.example.firstactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class secondactivity extends AppCompatActivity {
    TextView nameTV, phoneTV, genderTV, qualificationTV;
    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondactivity);

        nameTV = findViewById(R.id.nameTextView);
        phoneTV = findViewById(R.id.phoneTextView);
        genderTV = findViewById(R.id.genderTextView);
        qualificationTV = findViewById(R.id.qualificationTextView);
        backButton = findViewById(R.id.backButton);

        Intent intent = getIntent();
        String name = intent.getStringExtra("Name");
        String phone = intent.getStringExtra("Phone");
        String gender = intent.getStringExtra("Gender");
        String qualification = intent.getStringExtra("Qualification");

        // Set retrieved data to TextViews
        nameTV.setText("Name: " + name);
        phoneTV.setText("Phone Number: " + phone);
        genderTV.setText("Gender: " + gender);
        qualificationTV.setText("Qualification: " + qualification);

        // Set onClickListener for back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to go back to the main page
                Intent intent = new Intent(secondactivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optional, to close the current activity from the back stack
            }
        });
    }
}
