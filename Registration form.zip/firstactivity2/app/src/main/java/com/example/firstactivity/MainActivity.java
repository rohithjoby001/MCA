package com.example.firstactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText name, number;
    RadioButton male, female;
    Spinner qualificationSpinner;
    String radiogroup;
    String selectedQualification;
    String[] qualifications = {"Bachelors", "Masters", "PhD", "Diploma", "Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = (Button) findViewById(R.id.btn1);
        name = (EditText) findViewById(R.id.name);
        number = (EditText) findViewById(R.id.phone);
        male = (RadioButton) findViewById(R.id.male);
        female = (RadioButton) findViewById(R.id.female);
        qualificationSpinner = (Spinner) findViewById(R.id.qualificationSpinner);

        // Set up the ArrayAdapter for the spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, qualifications);
        qualificationSpinner.setAdapter(adapter);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (male.isChecked()) {
                    radiogroup = male.getText().toString();
                } else if (female.isChecked()) {
                    radiogroup = female.getText().toString();
                }

                String ne = name.getText().toString();
                String ph = number.getText().toString();
                selectedQualification = qualificationSpinner.getSelectedItem().toString();

                Intent i = new Intent(MainActivity.this, secondactivity.class);
                i.putExtra("Name", ne);
                i.putExtra("Phone", ph);
                i.putExtra("Gender", radiogroup);
                i.putExtra("Qualification", selectedQualification);
                startActivity(i);
            }
        });
    }
}
