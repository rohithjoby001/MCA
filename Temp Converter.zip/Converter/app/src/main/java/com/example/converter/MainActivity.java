package com.example.converter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText val;
    private Button tocelsius,tofaren;
    TextView  res;
    Double a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


           val = (EditText) findViewById(R.id.editText);
           tocelsius = (Button) findViewById(R.id.buttoncelsius);
           tofaren = (Button) findViewById(R.id.buttonfa);
           res = (TextView) findViewById(R.id.output);

            tocelsius.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                     a= Double.parseDouble(String.valueOf(val.getText()));
                     Double result = a * 9 / 5 + 32;
                      String r = String.valueOf(result);
                      res.setText(r);

                }
            });
            tofaren.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    a=Double.parseDouble(String.valueOf(val.getText()));
                    Double result = (a - 32) * 5/9;
                    String r = String.valueOf(result);
                    res.setText(r);
                }
            });


    }
}