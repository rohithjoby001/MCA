package com.example.implicitintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button Browser,call,text,camera;
    EditText url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         url = (EditText) findViewById(R.id.editURL);
         Browser = (Button) findViewById(R.id.button);
         call = (Button) findViewById(R.id.buttonCall);
         text = (Button) findViewById(R.id.buttonMessage);
        camera = (Button) findViewById(R.id.btncam);


        Browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String value = url.getText().toString();
                Intent i = new Intent(Intent.ACTION_VIEW,Uri.parse(value));
                startActivity(i);

            }
        });
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:9544382726"));
                startActivity(i);
            }
        });
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, "HELLO...");
                startActivity(i);

            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                startActivity(i);
            }
        });
    }
}